MonKey version: 1.4

Hi, and thanks for downloading MonKey!

To start using MonKey, simply press the HotKey (by default ` on a qwerty keyboard) to open the console!
You can as well go to Tool/MonKey Commander/Activate Command Console to open it the same way.

If the default Hotkey does not work for your keyboard configuration, you can change it in the preferences.

These are our top 10 commands, check them out!

-New Instance Under Mouse 
-Find Asset
-Find GameObject 
-Open Scene 
-Reset Transform 
-New Scriptable Object 
-Replace Selected GameObjects
-Rename Replace Term 
-Randomize Rotation / Scale / Position 
-Move Under Mouse

Check our full documentation over here for a step by step getting started, how to create your own commands, the full list of commands, and more:

https://sites.google.com/view/monkey-user-guide/home

If you have any problem, check our support section:

https://sites.google.com/view/monkey-commander/support

And if you want to follow news about us, check our facebook page or twitter:

https://www.facebook.com/MonKeyCommander/
https://twitter.com/BillSansky

Cheers,

The Jungle Team