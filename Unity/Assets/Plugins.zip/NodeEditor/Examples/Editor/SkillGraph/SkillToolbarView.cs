﻿//------------------------------------------------------------
// Author: 烟雨迷离半世殇
// Mail: 1778139321@qq.com
// Data: 2021年5月31日 19:15:32
//------------------------------------------------------------

using GraphProcessor;
using UnityEditor.Experimental.GraphView;

namespace Plugins.NodeEditor
{
    public class SkillToolbarView : NPBehaveToolbarView
    {
        public SkillToolbarView(BaseGraphView graphView, MiniMap miniMap, BaseGraph baseGraph) : base(graphView, miniMap, baseGraph)
        {
        }
    }
}