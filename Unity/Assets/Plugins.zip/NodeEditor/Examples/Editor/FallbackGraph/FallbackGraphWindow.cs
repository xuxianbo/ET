﻿//------------------------------------------------------------
// Author: 烟雨迷离半世殇
// Mail: 1778139321@qq.com
// Data: 2021年6月15日 11:58:14
//------------------------------------------------------------

namespace Plugins.NodeEditor
{
    /// <summary>
    /// 如果没有自定义Graph的Window，就使用这个兜底
    /// </summary>
    public class FallbackGraphWindow: UniversalGraphWindow
    {
    }
}